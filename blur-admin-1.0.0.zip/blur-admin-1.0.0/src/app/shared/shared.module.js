(function () {
  'use strict';

  angular.module('MyCvTracker.shared', [])
      .config(routeConfig);

  /** @ngInject */
  function routeConfig() {

  }

})();
