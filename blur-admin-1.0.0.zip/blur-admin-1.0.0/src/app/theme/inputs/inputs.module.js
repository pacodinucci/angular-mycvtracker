/**
 * @author v.lugovsky
 * created on 10.12.2016
 */
(function () {
  'use strict';

  angular.module('MyCvTracker.theme.inputs', []);

})();
