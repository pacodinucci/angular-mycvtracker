/**
 * @author v.lugovsky
 * created on 15.12.2015
 */
(function () {
  'use strict';

  angular.module('MyCvTracker.theme', [
      'toastr',
      'MyCvTracker.theme.components',
      'MyCvTracker.theme.inputs'
  ]);

})();
